print('hi')
print('Nitin')

#
print('hi',end='-') #print don't change the line
print('Nitin')

