a = 1
b =5

c = a+b
print(c)

#print('sum of {} and {} is {}'.format(a,b,c))
#print('sum of {1} and {0} is {2}'.format(a,b,c))

#print('sum of ',a,' and ',b,' is ',c)


#read data from user
#a = input('enter data :')
#b = input('enter data :')

#print(type(a))
#print(type(b))

#type casting / type change
#a = int(a)
#b = int(b)

#c =a+b
#print(c)

a= input( "input Name: ")
b= int(input( "input Roll number: "))
c=int(input( "Phone number: "))

s1= int(input( "s1 Marks: "))
s2= int(input( "s1 Marks: "))
s3= int(input( "s1 Marks: "))
s4= int(input( "s1 Marks: "))
s5= int(input( "s1 Marks: "))

total = s1+s2+s3+s4+s5
avg =(total)/5

print("name: ", a)
print("roll nio: ", b)
print("phone : ", c)

print("Total Marks: ", total)
print("Average: ", avg)

